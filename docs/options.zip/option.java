import org.apache.commons.math3.distribution.NormalDistribution;

public class option {
	
	private double st; // current stock price
	private double k; // strike price
	private double v; // volatility
	private double r; // interest rate
	private double t; // current time
	private double T; // maturity date
	private double C; // call price
	private double P; // put price
	
	//Option constructor
	public option() {
		//Default values
		this.st=100;
		this.k=100; 
		this.v=0.25;
		this.r=0.05;
		this.t=0;
		this.T=1;
	}
	
	// Current stock price set and get
	public void setStockPrice(double S) {
		this.st = S;
	}
	
	public double getStockPrice(){
		return this.st;
	}
	
	// Strike set and get
	public void setStrike(double strike) {
		this.k = strike;
	}
	
	public double getStrike(){
		return this.k;
	}
	
	// Volatility set and get
	public void setVol(double vol) {
		this.v = vol;
	}
	
	public double getVol(){
		return this.v;
	}
	
	// Interest rates set and get
	public void setRates(double rates) {
		this.r = rates;
	}
	
	public double getRates(){
		return this.r;
	}
	
	// Current time set and get
	public void setCurrentTime(double time) {
		this.t = time;
	}
	
	public double getCurrentTime(){
		return this.t;
	}
	
	// Maturity date set and get
	public void setMaturity(double maturity) {
		this.T = maturity;
	}
	
	public double getMaturity(){
		return this.T;
	}
	
	// Call price get
	public double getCall(){
		return this.C;
	}
	
	// Put price get
	public double getPut(){
		return this.P;
	}
	
	// Method for calculating call price
	public void calcCallPrice() {
		double price;
		double CPPst = this.st; // current stock price
		double CPPk = this.k; // strike price
		double CPPv = this.v; // volatility
		double CPPr = this.r; // interest rate
		double CPPt = this.t; // current time
		double CPPT = this.T; // maturity date
		
		//If at expiry		
		if (CPPT-CPPt==0) {
			
			//If else to get (S-K)+
			if (CPPst - CPPk > 0) {
				price = CPPst - CPPk;
			}
			else {
				price = 0;
			}
		}
		//If not at expiry
		else {
			double temp1 = Math.log(CPPst/CPPk)+(CPPr + 0.5*CPPv*CPPv)*(CPPT-CPPt);
			
			double d1;
			
			//If volatility is zero 
			if (CPPv == 0) {
				d1 = Double.POSITIVE_INFINITY;
			}
			
			//If volatility is not zero 
			else {
				d1 = temp1/(CPPv*Math.sqrt(CPPT -CPPt));
			}
			
			double d2 = d1 - CPPv*Math.sqrt(CPPT -CPPt);
			NormalDistribution normal = new NormalDistribution();
			double cumd1 = normal.cumulativeProbability(d1);
			double cumd2 = normal.cumulativeProbability(d2);
			price = CPPst*cumd1-CPPk*cumd2*Math.exp(-CPPr*(CPPT-CPPt));
			
		}

		this.C = price;
		
	}
	
	// Method for calculating call price
	public void calcPutPrice() {
		double price;
		double CPPst = this.st; // current stock price
		double CPPk = this.k; // strike price
		double CPPv = this.v; // volatility
		double CPPr = this.r; // interest rate
		double CPPt = this.t; // current time
		double CPPT = this.T; // maturity date
		
		//If at expiry
		if (CPPT-CPPt==0) {
			//If else to get (K-S)+
			if (CPPk - CPPst > 0) {
				price = CPPk -CPPst;
			}
			else {
				price = 0;
			}
		}
		//If not at expiry
		else {
			
			double temp1 = Math.log(CPPst/CPPk)+(CPPr + 0.5*CPPv*CPPv)*(CPPT-CPPt);

			double d1;
			
			//If volatility is zero 
			if (CPPv == 0) {
				d1 = Double.POSITIVE_INFINITY;
			}
			
			//If volatility is not zero 
			else {
				d1 = temp1/(CPPv*Math.sqrt(CPPT -CPPt));
			}
			double d2 = d1 - CPPv*Math.sqrt(CPPT -CPPt);
			NormalDistribution normal = new NormalDistribution();
			double cumd1 = normal.cumulativeProbability(-d1);
			double cumd2 = normal.cumulativeProbability(-d2);
			price = CPPk*cumd2*Math.exp(-CPPr*(CPPT-CPPt)) -  CPPst*cumd1;
				
		}
		
		this.P = price;
	}
	

	
	
}